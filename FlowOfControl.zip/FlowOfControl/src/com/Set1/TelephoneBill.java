package com.Set1;

import java.util.Scanner;

public class TelephoneBill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of calls: ");
        int calls = input.nextInt();

        double bill=0;
        if (calls>=0 && calls <= 100)
        {
            bill = 200;
        } 
        else if (calls>100 && calls <= 150)
        {
            calls=calls-100;
            bill=200+(calls*0.60);
        } 
        else if (calls>150 && calls <= 200)
        {
        	calls=calls-150;
            bill = 200 + (50 * 0.60)+ (calls * 0.50);
        } 
        else if(calls>200)
        {
        	calls=calls-200;
            bill = 200 +( 50 * 0.60) + (50 * 0.50)+ (calls * 0.40);
        }
        else {
        	bill=0;
        	System.out.println("Invalid Input");
        }

        System.out.println("The bill is Rs. " + bill);
	}

}
