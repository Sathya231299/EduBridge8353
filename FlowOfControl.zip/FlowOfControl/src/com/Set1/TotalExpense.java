package com.Set1;

import java.util.Scanner;

public class TotalExpense {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double quantity,amount,discount,price;
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the Quantity Purchased : ");
		 quantity = input.nextDouble();
		 
		 System.out.print("Enter the Amount Per Item : ");
	      price = input.nextDouble();
	      
	      amount=quantity*price;
	      if(amount>=5000) {
	               discount=amount*0.1;
	               amount=amount-discount;
	               System.out.println("Total Price of product is : "+amount);
	    	  
	      }else {
		System.out.println("Total Price of product is : "+amount);
	}
	}
}
