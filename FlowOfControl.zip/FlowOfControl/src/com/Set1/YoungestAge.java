package com.Set1;

import java.util.Scanner;

public class YoungestAge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Ram Age : ");
		int ram=input.nextInt();
		System.out.println("Enter Sulabh Age : ");
		int sulabh=input.nextInt();
		System.out.println("Enter Ajay Age : ");
		int ajay=input.nextInt();
		
		if((ram<sulabh)&&(ram<ajay)) {
			System.out.println("Ram is younger");
		}
		else if((sulabh<ram)&&(sulabh<ajay)) {
			System.out.println("Sulabh is younger");
		}
		else {
			System.out.println("Ajay is younger");
		}
		

	}

}
