package com.Set1;

import java.util.Scanner;

public class EvenOrOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter an Integer : ");
		int num=scanner.nextInt();
		if(num%2==0) {
			System.out.println(num+ " is an Even number");
		}
		else {
			System.out.println(num+ " is an Odd number");
		}

	}

}
