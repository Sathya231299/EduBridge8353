package com.Set1;

import java.util.Scanner;

public class GrossSalary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float Gross_Salary,da1,hra1;
       Scanner input=new Scanner(System.in);
       System.out.println("Enter Basic_Salary : ");
       float basicsalary=input.nextFloat();
       System.out.println("Enter HRA : ");
       int hra=input.nextInt();
       System.out.println("Enter DA : ");
       int da=input.nextInt();
       
       Gross_Salary=basicsalary+hra+da;
       System.out.println("Gross Salary of employer is : "+Gross_Salary);
	}

}
