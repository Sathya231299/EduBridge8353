package com.Set1;

import java.util.Scanner;

public class Triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int angle1,angle2,angle3,total;
          Scanner input=new Scanner(System.in);
          System.out.println("Enter First Angle : ");
          angle1=input.nextInt();
          System.out.println("Enter Second Angle : ");
          angle2=input.nextInt();
          System.out.println("Enter Third Angle : ");
          angle3=input.nextInt();
          total=angle1+angle2+angle3;
          System.out.println("The Sum of three angles : "+total);
          if(total==180) {
        	  System.out.println("The Triangle is valid");
          }
          else {
        	  System.out.println("The Triangle is not valid");
          }
	}

}
