package com.Set1;

import java.util.Scanner;

public class AbsoluteValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter a number : ");
      int num=sc.nextInt();
      if(num<0) {
          int abs=-num;
    	  System.out.printf("The Absolute Value of "+num+" is :"+abs);
      }
      else
      {
    	  System.out.println("The Absolute Value of "+num+" is :"+num);
      }
	}

}
