package com.Set1;

import java.util.Scanner;

public class Profit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter cost Price : ");
        int cp=sc.nextInt();
        System.out.println("Enter Selling Price : ");
        int sp=sc.nextInt();
        
        if(sp-cp>0) {
        	System.out.println("Profit : "+(sp-cp));
        }else  {
        	System.out.println("Loss : "+(cp-sp));
        }
	}

}
