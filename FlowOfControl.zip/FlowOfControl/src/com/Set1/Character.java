package com.Set1;

import java.util.Scanner;

public class Character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner input=new Scanner(System.in);
         System.out.println("Enter a character : ");
         char ch=input.next().charAt(0);
         int value=ch;
        if(ch>=65 && ch<=90) {
        	System.out.println(ch+" is a Capital Letter");
        }
        else if(ch>=97 && ch<=122) {
        	System.out.println(ch+" is Lower Case Letter");
        }
        else if(ch>=48 && ch<=57) {
        	System.out.println(ch+" is a digit");
        }
        else if((ch>=0 && ch<=47)||(ch>=58 && ch<=64)||(ch<=91 && ch<=96)||(ch<=123 && ch<=127)) {
        	System.out.println(ch+" is a Special Symbols");
        }
        else {
        	System.out.println(ch+" is not a character");
        }
        System.out.println("The ASCII value of "+ch+" is : "+value);
        	
        }
	}


