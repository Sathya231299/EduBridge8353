package com.Set1;

import java.util.Scanner;

public class Percentage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Scanner input=new Scanner(System.in);
          System.out.println("Enter Student marks in 1st subject : ");
	       int m1=input.nextInt();
	       System.out.println("Enter Student marks in 2nd subject : ");
	       int m2=input.nextInt();
	       System.out.println("Enter Student marks in 3rd subject : ");
	       int m3=input.nextInt();
	       System.out.println("Enter Student marks in 4th subject : ");
	       int m4=input.nextInt();
	       System.out.println("Enter Student marks in 5th subject : ");
	       int m5=input.nextInt();
	       
	       long total=m1+m2+m3+m4+m5;
	       float percentage=total/5;
	      
	       if(percentage>=60) {
	    	   System.out.println("First Division");
	       }
	       else if(percentage>=50 && percentage<=59) {
	    	   System.out.println("Second Division");
	       }
	       else if(percentage>=40 && percentage<=49) {
	    	   System.out.println("Third Division");
	       }
	       else{
	    	   System.out.println("Fail");
	       }
	}

}
