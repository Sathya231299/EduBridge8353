package com.Set2;

public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=3;i>=1;i--)
		{
			for(int k=3;k>i;k--)
			{
				System.out.print("  ");
			}
			
			for(int j=i;j>=1;j--)
			{
			System.out.print(j+" ");
			}
			for(int l=1;l<=i-1;l++)
			{
				System.out.print(l+1+" ");
			}
			System.out.println();
			}
	}
          }
/*
 * 32123
 *  212 
 *   1
 * 
 */
