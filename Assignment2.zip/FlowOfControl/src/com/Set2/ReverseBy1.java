package com.Set2;

public class ReverseBy1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=3;i>=1;i--) {
       	 
      	  for(int j=2;j>=i;j--) {
      		  System.out.print(" ");
      	  }
      	  
      	  for(int k=1;k<=i;k++) {
      	       System.out.print(k);
             }
      	  for(int l=i;l>1;l--) {
      		  System.out.print(l-1);
      	  }
      	  System.out.println();
	}

}
}