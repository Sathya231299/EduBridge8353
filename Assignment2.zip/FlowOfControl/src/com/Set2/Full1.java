package com.Set2;

public class Full1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 for(int i=1;i<=3;i++) {
	          for(int j=2;j>=i;j--) {
	    	   System.out.print(" ");
	       }
	          for(int l=1;l<=2*i-1;l++) {
	        	  if((l==1)||(l==2*i-1)) {
	        		  System.out.print("1");
	        	  }else {
	        	  System.out.print("*");
	          }}
	          System.out.println();
		}

	       for(int i=2;i>=1;i--) {
	           for(int j=2;j>=i;j--) {
	     	   System.out.print(" ");
	        }
	           for(int l=1;l<=2*i-1;l++) {
	        	   if((l==1)||(l==2*i-1)) {
		        		  System.out.print("1");
		        	  }else {
		        	  System.out.print("*");
		          }
	           }
	           System.out.println();
	}
	}

}
